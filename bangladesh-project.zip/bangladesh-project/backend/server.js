const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');

dotenv.config();

connectDB();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/location', require('./routes/locationRoutes'));
app.use('/api/posts', require('./routes/postRoutes'));

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'বাংলাদেশ ভৌগোলিক তথ্যকোষ API চলছে',
  });
});

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'এই রুট খুঁজে পাওয়া যায়নি',
  });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 সার্ভার চালু হয়েছে পোর্ট ${PORT} এ`);
});