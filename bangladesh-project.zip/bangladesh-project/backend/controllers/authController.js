const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

const registerUser = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      password,
      division,
      district,
      upazila,
      thana,
      village,
      house,
    } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'নাম, ইমেইল ও পাসওয়ার্ড দিতে হবে',
      });
    }

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে',
      });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = await User.create({
      name,
      email,
      phone,
      password: hashedPassword,
      division,
      district,
      upazila,
      thana,
      village,
      house,
    });

    res.status(201).json({
      success: true,
      message: 'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে',
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        division: user.division,
        district: user.district,
        upazila: user.upazila,
        thana: user.thana,
        village: user.village,
        house: user.house,
        token: generateToken(user._id),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'অ্যাকাউন্ট তৈরি করা যায়নি',
      error: error.message,
    });
  }
};

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'ইমেইল ও পাসওয়ার্ড দিতে হবে',
      });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'ইমেইল বা পাসওয়ার্ড ভুল',
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'ইমেইল বা পাসওয়ার্ড ভুল',
      });
    }

    res.status(200).json({
      success: true,
      message: 'লগইন সফল হয়েছে',
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        division: user.division,
        district: user.district,
        upazila: user.upazila,
        thana: user.thana,
        village: user.village,
        house: user.house,
        token: generateToken(user._id),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'লগইন করা যায়নি',
      error: error.message,
    });
  }
};

const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password')
      .populate('division district upazila thana village house');

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'তথ্য আনা যায়নি',
      error: error.message,
    });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getMe,
};