const Post = require('../models/Post');
const path = require('path');
const fs = require('fs');

const createPost = async (req, res) => {
  try {
    const {
      title,
      description,
      division,
      district,
      upazila,
      thana,
      village,
      house,
    } = req.body;

    if (!title || !division || !district || !upazila || !thana || !village) {
      return res.status(400).json({
        success: false,
        message: 'শিরোনাম ও ঠিকানার সব তথ্য দিতে হবে',
      });
    }

    const images = [];
    if (req.files && req.files.length > 0) {
      req.files.forEach((file) => {
        images.push(`/uploads/${file.filename}`);
      });
    }

    const post = await Post.create({
      title,
      description,
      images,
      user: req.user._id,
      division,
      district,
      upazila,
      thana,
      village,
      house,
    });

    res.status(201).json({
      success: true,
      message: 'পোস্ট সফলভাবে তৈরি হয়েছে',
      data: post,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'পোস্ট তৈরি করা যায়নি',
      error: error.message,
    });
  }
};

const getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('user', 'name email')
      .populate('division district upazila thana village house')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: posts.length,
      data: posts,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getPostsByLocation = async (req, res) => {
  try {
    const { villageId } = req.params;
    const posts = await Post.find({ village: villageId })
      .populate('user', 'name email')
      .populate('division district upazila thana village house')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: posts.length,
      data: posts,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('user', 'name email')
      .populate('division district upazila thana village house');

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'পোস্ট খুঁজে পাওয়া যায়নি',
      });
    }

    res.status(200).json({ success: true, data: post });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updatePost = async (req, res) => {
  try {
    let post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'পোস্ট খুঁজে পাওয়া যায়নি',
      });
    }

    if (post.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'এই পোস্ট সম্পাদনার অনুমতি নেই',
      });
    }

    post = await Post.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.status(200).json({
      success: true,
      message: 'পোস্ট আপডেট হয়েছে',
      data: post,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'পোস্ট খুঁজে পাওয়া যায়নি',
      });
    }

    if (post.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'এই পোস্ট মুছে ফেলার অনুমতি নেই',
      });
    }

    if (post.images && post.images.length > 0) {
      post.images.forEach((imgPath) => {
        const fullPath = path.join(__dirname, '..', imgPath);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      });
    }

    await post.deleteOne();

    res.status(200).json({
      success: true,
      message: 'পোস্ট মুছে ফেলা হয়েছে',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createPost,
  getAllPosts,
  getPostsByLocation,
  getPostById,
  updatePost,
  deletePost,
};