const Division = require('../models/Division');
const District = require('../models/District');
const Upazila = require('../models/Upazila');
const Thana = require('../models/Thana');
const Village = require('../models/Village');
const House = require('../models/House');

const getDivisions = async (req, res) => {
  try {
    const divisions = await Division.find().sort({ name: 1 });
    res.status(200).json({ success: true, count: divisions.length, data: divisions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getDistricts = async (req, res) => {
  try {
    const { divisionId } = req.params;
    const districts = await District.find({ division: divisionId }).sort({ name: 1 });
    res.status(200).json({ success: true, count: districts.length, data: districts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getUpazilas = async (req, res) => {
  try {
    const { districtId } = req.params;
    const upazilas = await Upazila.find({ district: districtId }).sort({ name: 1 });
    res.status(200).json({ success: true, count: upazilas.length, data: upazilas });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getThanas = async (req, res) => {
  try {
    const { upazilaId } = req.params;
    const thanas = await Thana.find({ upazila: upazilaId }).sort({ name: 1 });
    res.status(200).json({ success: true, count: thanas.length, data: thanas });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getVillages = async (req, res) => {
  try {
    const { thanaId } = req.params;
    const villages = await Village.find({ thana: thanaId }).sort({ name: 1 });
    res.status(200).json({ success: true, count: villages.length, data: villages });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getHouses = async (req, res) => {
  try {
    const { villageId } = req.params;
    const houses = await House.find({ village: villageId }).sort({ name: 1 });
    res.status(200).json({ success: true, count: houses.length, data: houses });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createDivision = async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({
        success: false,
        message: 'বিভাগের নাম দিতে হবে',
      });
    }

    const existing = await Division.findOne({ name });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই বিভাগ আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const division = await Division.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন বিভাগ যোগ হয়েছে',
      data: division,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createDistrict = async (req, res) => {
  try {
    const { name, division } = req.body;

    if (!name || !division) {
      return res.status(400).json({
        success: false,
        message: 'নাম ও বিভাগ দিতে হবে',
      });
    }

    const existing = await District.findOne({ name, division });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই জেলা আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const district = await District.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন জেলা যোগ হয়েছে',
      data: district,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createUpazila = async (req, res) => {
  try {
    const { name, district } = req.body;

    if (!name || !district) {
      return res.status(400).json({
        success: false,
        message: 'নাম ও জেলা দিতে হবে',
      });
    }

    const existing = await Upazila.findOne({ name, district });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই উপজেলা আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const upazila = await Upazila.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন উপজেলা যোগ হয়েছে',
      data: upazila,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createThana = async (req, res) => {
  try {
    const { name, upazila } = req.body;

    if (!name || !upazila) {
      return res.status(400).json({
        success: false,
        message: 'নাম ও উপজেলা দিতে হবে',
      });
    }

    const existing = await Thana.findOne({ name, upazila });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই থানা আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const thana = await Thana.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন থানা যোগ হয়েছে',
      data: thana,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createVillage = async (req, res) => {
  try {
    const { name, thana } = req.body;

    if (!name || !thana) {
      return res.status(400).json({
        success: false,
        message: 'নাম ও থানা দিতে হবে',
      });
    }

    const existing = await Village.findOne({ name, thana });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই গ্রাম আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const village = await Village.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন গ্রাম যোগ হয়েছে',
      data: village,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createHouse = async (req, res) => {
  try {
    const { name, village } = req.body;

    if (!name || !village) {
      return res.status(400).json({
        success: false,
        message: 'নাম ও গ্রাম দিতে হবে',
      });
    }

    const existing = await House.findOne({ name, village });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'এই বাড়ি আগেই আছে',
        data: existing,
        isNew: false,
      });
    }

    const house = await House.create(req.body);
    res.status(201).json({
      success: true,
      message: 'নতুন বাড়ি যোগ হয়েছে',
      data: house,
      isNew: true,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getDivisions,
  getDistricts,
  getUpazilas,
  getThanas,
  getVillages,
  getHouses,
  createDivision,
  createDistrict,
  createUpazila,
  createThana,
  createVillage,
  createHouse,
};