const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');

      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'ব্যবহারকারী খুঁজে পাওয়া যায়নি',
        });
      }

      next();
    } catch (error) {
      return res.status(401).json({
        success: false,
        message: 'টোকেন সঠিক নয়',
      });
    }
  } else {
    return res.status(401).json({
      success: false,
      message: 'লগইন করা প্রয়োজন',
    });
  }
};

module.exports = { protect };