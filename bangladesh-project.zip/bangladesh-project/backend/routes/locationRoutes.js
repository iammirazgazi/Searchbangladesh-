const express = require('express');
const router = express.Router();
const {
  getDivisions,
  getDistricts,
  getUpazilas,
  getThanas,
  getVillages,
  getHouses,
  createDivision,
  createDistrict,
  createUpazila,
  createThana,
  createVillage,
  createHouse,
} = require('../controllers/locationController');

router.get('/divisions', getDivisions);
router.get('/districts/:divisionId', getDistricts);
router.get('/upazilas/:districtId', getUpazilas);
router.get('/thanas/:upazilaId', getThanas);
router.get('/villages/:thanaId', getVillages);
router.get('/houses/:villageId', getHouses);

router.post('/divisions', createDivision);
router.post('/districts', createDistrict);
router.post('/upazilas', createUpazila);
router.post('/thanas', createThana);
router.post('/villages', createVillage);
router.post('/houses', createHouse);

module.exports = router;