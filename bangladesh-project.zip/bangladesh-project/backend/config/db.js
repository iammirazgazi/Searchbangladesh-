const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`✅ MongoDB সংযুক্ত হয়েছে: ${conn.connection.host}`);
    console.log(`📂 ডাটাবেসের নাম: ${conn.connection.name}`);
  } catch (error) {
    console.error(`❌ ডাটাবেস সংযোগে সমস্যা: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;