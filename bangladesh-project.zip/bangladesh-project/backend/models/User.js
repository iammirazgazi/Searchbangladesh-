const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'নাম দিতে হবে'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'ইমেইল দিতে হবে'],
      unique: true,
      lowercase: true,
      trim: true,
    },
    phone: {
      type: String,
      trim: true,
    },
    password: {
      type: String,
      required: [true, 'পাসওয়ার্ড দিতে হবে'],
      minlength: 6,
    },
    role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user',
    },
    division: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Division',
    },
    district: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'District',
    },
    upazila: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Upazila',
    },
    thana: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Thana',
    },
    village: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Village',
    },
    house: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'House',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('User', userSchema);