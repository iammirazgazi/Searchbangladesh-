const mongoose = require('mongoose');

const upazilaSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'উপজেলার নাম দিতে হবে'],
      trim: true,
    },
    nameEn: {
      type: String,
      trim: true,
    },
    code: {
      type: String,
      trim: true,
    },
    district: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'District',
      required: [true, 'জেলা সিলেক্ট করতে হবে'],
    },
    description: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Upazila', upazilaSchema);