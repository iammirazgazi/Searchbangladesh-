const mongoose = require('mongoose');

const villageSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'গ্রামের নাম দিতে হবে'],
      trim: true,
    },
    nameEn: {
      type: String,
      trim: true,
    },
    code: {
      type: String,
      trim: true,
    },
    thana: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Thana',
      required: [true, 'থানা সিলেক্ট করতে হবে'],
    },
    postOffice: {
      type: String,
      trim: true,
    },
    postalCode: {
      type: String,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Village', villageSchema);