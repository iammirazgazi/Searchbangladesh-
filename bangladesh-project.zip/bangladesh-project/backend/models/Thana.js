const mongoose = require('mongoose');

const thanaSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'থানার নাম দিতে হবে'],
      trim: true,
    },
    nameEn: {
      type: String,
      trim: true,
    },
    code: {
      type: String,
      trim: true,
    },
    upazila: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Upazila',
      required: [true, 'উপজেলা সিলেক্ট করতে হবে'],
    },
    description: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Thana', thanaSchema);