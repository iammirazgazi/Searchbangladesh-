# Bangladesh Project

বাংলাদেশের বিভাগ, জেলা, উপজেলা, থানা, গ্রাম, বাড়ি, ব্যবহারকারী এবং পোস্টের তথ্য ব্যবস্থাপনার জন্য একটি starter project structure।

## Folder overview
- `backend/` — Express API starter
- `database/schema.sql` — MySQL database schema
- `database/seed.sql` — sample seed record (complete location dataset নয়)
- `frontend/` — basic HTML starter pages

## Backend চালু করার প্রাথমিক ধাপ
1. Node.js এবং MySQL/MariaDB ইনস্টল করুন।
2. `database/schema.sql` ডাটাবেসে রান করুন।
3. `backend/.env` ফাইলে নিজের database credentials এবং একটি নিরাপদ `JWT_SECRET` দিন।
4. টার্মিনালে `backend` ফোল্ডারে গিয়ে `npm install` চালান।
5. `npm run dev` অথবা `npm start` চালান।
6. `http://localhost:5000/api/health` খুলে API চালু আছে কি না পরীক্ষা করুন।

## গুরুত্বপূর্ণ
এটি ফোল্ডার-স্ট্রাকচার ও প্রাথমিক starter code। Register/login, authentication, location CRUD API, file upload validation, frontend integration এবং বাংলাদেশের সম্পূর্ণ নির্ভুল স্থানতথ্য এখনও বাস্তবায়ন/যোগ করা হয়নি। `.env`-এর গোপন তথ্য কাউকে শেয়ার করবেন না।
