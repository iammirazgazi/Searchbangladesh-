-- Sample starter records only. This is NOT the complete official Bangladesh dataset.
USE bangladesh_project;

INSERT INTO divisions (name_bn, name_en)
SELECT 'চট্টগ্রাম', 'Chattogram'
WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name_en = 'Chattogram');
