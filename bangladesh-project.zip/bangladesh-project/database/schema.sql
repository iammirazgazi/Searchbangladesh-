-- Starter schema for the Bangladesh location information project.
-- MySQL / MariaDB. Review and run this file in your database tool.

CREATE DATABASE IF NOT EXISTS bangladesh_project
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bangladesh_project;

CREATE TABLE IF NOT EXISTS divisions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name_bn VARCHAR(120) NOT NULL,
  name_en VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS districts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  division_id INT NOT NULL,
  name_bn VARCHAR(120) NOT NULL,
  name_en VARCHAR(120),
  FOREIGN KEY (division_id) REFERENCES divisions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS upazilas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  district_id INT NOT NULL,
  name_bn VARCHAR(120) NOT NULL,
  name_en VARCHAR(120),
  FOREIGN KEY (district_id) REFERENCES districts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS thanas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  upazila_id INT,
  district_id INT NOT NULL,
  name_bn VARCHAR(120) NOT NULL,
  name_en VARCHAR(120),
  FOREIGN KEY (upazila_id) REFERENCES upazilas(id) ON DELETE SET NULL,
  FOREIGN KEY (district_id) REFERENCES districts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS villages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  thana_id INT NOT NULL,
  name_bn VARCHAR(160) NOT NULL,
  name_en VARCHAR(160),
  FOREIGN KEY (thana_id) REFERENCES thanas(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS houses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  village_id INT NOT NULL,
  house_name VARCHAR(160),
  address TEXT,
  FOREIGN KEY (village_id) REFERENCES villages(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  body TEXT,
  image_path VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
